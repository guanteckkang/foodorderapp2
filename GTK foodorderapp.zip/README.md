This project was created by GuanTeckKang for the assignment by talentlab. In order to complete assignment project 2.
